﻿namespace SFA
{
    internal class AppSettings
    {
    }
}