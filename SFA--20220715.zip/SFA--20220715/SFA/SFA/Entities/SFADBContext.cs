﻿using System;
using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata;

namespace SFA.Entities
{
    public partial class SFADBContext : DbContext
    {
        public SFADBContext()
        {
        }

        public SFADBContext(DbContextOptions<SFADBContext> options)
            : base(options)
        {
        }

        public virtual DbSet<TblAppointment> TblAppointment { get; set; }
        public virtual DbSet<TblAttribute> TblAttribute { get; set; }
        public virtual DbSet<TblAttributeType> TblAttributeType { get; set; }
        public virtual DbSet<TblChurch> TblChurch { get; set; }
        public virtual DbSet<TblChurchAccommodation> TblChurchAccommodation { get; set; }
        public virtual DbSet<TblChurchServiceTime> TblChurchServiceTime { get; set; }
        public virtual DbSet<TblCountry> TblCountry { get; set; }
        public virtual DbSet<TblDistrict> TblDistrict { get; set; }
        public virtual DbSet<TblMacroSchedule> TblMacroSchedule { get; set; }
        public virtual DbSet<TblMacroScheduleDetails> TblMacroScheduleDetails { get; set; }
        public virtual DbSet<TblMenu> TblMenu { get; set; }
        public virtual DbSet<TblMenuGroup> TblMenuGroup { get; set; }
        public virtual DbSet<TblRole> TblRole { get; set; }
        public virtual DbSet<TblRoleMenu> TblRoleMenu { get; set; }
        public virtual DbSet<TblSection> TblSection { get; set; }
        public virtual DbSet<TblServiceType> TblServiceType { get; set; }
        public virtual DbSet<TblState> TblState { get; set; }
        public virtual DbSet<TblStateDistrict> TblStateDistrict { get; set; }
        public virtual DbSet<TblUser> TblUser { get; set; }
        public virtual DbSet<TblUserAttribute> TblUserAttribute { get; set; }
        public virtual DbSet<TblUserChurch> TblUserChurch { get; set; }
        public virtual DbSet<TblUserPassword> TblUserPassword { get; set; }


        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            modelBuilder.Entity<TblAppointment>(entity =>
            {
                entity.ToTable("Tbl_Appointment", "Global");

                entity.Property(e => e.Id).ValueGeneratedNever();

                entity.Property(e => e.AcceptByPastorOn).HasColumnType("datetime");

                entity.Property(e => e.AcceptByPastorRemarks).HasMaxLength(100);

                entity.Property(e => e.AcceptMissionaryOn).HasColumnType("datetime");

                entity.Property(e => e.AcceptMissionaryRemarks).HasMaxLength(100);

                entity.Property(e => e.CreatedOn).HasColumnType("datetime");

                entity.Property(e => e.Description).HasMaxLength(100);

                entity.Property(e => e.EventDate).HasColumnType("date");

                entity.Property(e => e.Notes).HasMaxLength(100);

                entity.Property(e => e.Offering).HasMaxLength(100);

                entity.Property(e => e.PimAmount).HasColumnType("numeric(18, 2)");

                entity.Property(e => e.SubmittedOn).HasColumnType("datetime");

                entity.HasOne(d => d.AcceptByPastorByNavigation)
                    .WithMany(p => p.TblAppointmentAcceptByPastorByNavigation)
                    .HasForeignKey(d => d.AcceptByPastorBy)
                    .HasConstraintName("FK_Tbl_Appointment_Tbl_User2");

                entity.HasOne(d => d.AcceptMissionaryByNavigation)
                    .WithMany(p => p.TblAppointmentAcceptMissionaryByNavigation)
                    .HasForeignKey(d => d.AcceptMissionaryBy)
                    .HasConstraintName("FK_Tbl_Appointment_Tbl_User3");

                entity.HasOne(d => d.Church)
                    .WithMany(p => p.TblAppointment)
                    .HasForeignKey(d => d.ChurchId)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("FK_Tbl_Appointment_Tbl_Church");

                entity.HasOne(d => d.CreatedByNavigation)
                    .WithMany(p => p.TblAppointmentCreatedByNavigation)
                    .HasForeignKey(d => d.CreatedBy)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("FK_Tbl_Appointment_Tbl_User");

                entity.HasOne(d => d.MacroScheduleDetail)
                    .WithMany(p => p.TblAppointment)
                    .HasForeignKey(d => d.MacroScheduleDetailId)
                    .HasConstraintName("FK_Tbl_Appointment_Tbl_MacroScheduleDetails");

                entity.HasOne(d => d.SubmittedByNavigation)
                    .WithMany(p => p.TblAppointmentSubmittedByNavigation)
                    .HasForeignKey(d => d.SubmittedBy)
                    .HasConstraintName("FK_Tbl_Appointment_Tbl_User1");
            });

            modelBuilder.Entity<TblAttribute>(entity =>
            {
                entity.ToTable("Tbl_Attribute", "Global");

                entity.Property(e => e.Id).ValueGeneratedNever();

                entity.Property(e => e.AttributeName)
                    .IsRequired()
                    .HasMaxLength(100);

                entity.Property(e => e.AttributeNotes).HasMaxLength(150);

                entity.HasOne(d => d.AttributeType)
                    .WithMany(p => p.TblAttribute)
                    .HasForeignKey(d => d.AttributeTypeId)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("FK_Tbl_Attribute_Tbl_AttributeType");
            });

            modelBuilder.Entity<TblAttributeType>(entity =>
            {
                entity.ToTable("Tbl_AttributeType", "Global");

                entity.Property(e => e.Id).ValueGeneratedNever();

                entity.Property(e => e.Name)
                    .IsRequired()
                    .HasMaxLength(100);
            });

            modelBuilder.Entity<TblChurch>(entity =>
            {
                entity.ToTable("Tbl_Church", "Global");

                entity.Property(e => e.Id).ValueGeneratedNever();

                entity.Property(e => e.AccountNo).HasMaxLength(50);

                entity.Property(e => e.Address).HasMaxLength(200);

                entity.Property(e => e.ChurchName)
                    .IsRequired()
                    .HasMaxLength(150);

                entity.Property(e => e.ChurchType).HasMaxLength(50);

                entity.Property(e => e.CreatedOn).HasColumnType("datetime");

                entity.Property(e => e.DeletedOn).HasColumnType("datetime");

                entity.Property(e => e.Directory).HasMaxLength(300);

                entity.Property(e => e.Email).HasMaxLength(50);

                entity.Property(e => e.LastModifiedOn).HasColumnType("datetime");

                entity.Property(e => e.Lat)
                    .HasColumnName("lat")
                    .HasMaxLength(50);

                entity.Property(e => e.Lon)
                    .HasColumnName("lon")
                    .HasMaxLength(50);

                entity.Property(e => e.MailAddress).HasMaxLength(200);

                entity.Property(e => e.Phone).HasMaxLength(50);

                entity.Property(e => e.Phone2).HasMaxLength(50);

                entity.Property(e => e.Status).HasMaxLength(50);

                entity.Property(e => e.WebSite).HasMaxLength(50);

                entity.HasOne(d => d.CreatedByNavigation)
                    .WithMany(p => p.TblChurchCreatedByNavigation)
                    .HasForeignKey(d => d.CreatedBy)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("FK_Tbl_Church_Tbl_User");

                entity.HasOne(d => d.DeletedByNavigation)
                    .WithMany(p => p.TblChurchDeletedByNavigation)
                    .HasForeignKey(d => d.DeletedBy)
                    .HasConstraintName("FK_Tbl_Church_Tbl_User2");

                entity.HasOne(d => d.District)
                    .WithMany(p => p.TblChurch)
                    .HasForeignKey(d => d.DistrictId)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("FK_Tbl_Church_Tbl_District");

                entity.HasOne(d => d.LastModifiedByNavigation)
                    .WithMany(p => p.TblChurchLastModifiedByNavigation)
                    .HasForeignKey(d => d.LastModifiedBy)
                    .HasConstraintName("FK_Tbl_Church_Tbl_User1");

                entity.HasOne(d => d.Section)
                    .WithMany(p => p.TblChurch)
                    .HasForeignKey(d => d.SectionId)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("FK_Tbl_Church_Tbl_Section");
            });

            modelBuilder.Entity<TblChurchAccommodation>(entity =>
            {
                entity.ToTable("Tbl_ChurchAccommodation", "Global");

                entity.Property(e => e.Id).ValueGeneratedNever();

                entity.Property(e => e.AccomNotes).HasMaxLength(250);

                entity.Property(e => e.AccomType).HasMaxLength(50);

                entity.HasOne(d => d.Church)
                    .WithMany(p => p.TblChurchAccommodation)
                    .HasForeignKey(d => d.ChurchId)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("FK_Tbl_ChurchAccommodation_Tbl_Church");
            });

            modelBuilder.Entity<TblChurchServiceTime>(entity =>
            {
                entity.ToTable("Tbl_ChurchServiceTime", "Global");

                entity.Property(e => e.Id).ValueGeneratedNever();

                entity.Property(e => e.CreatedOn).HasColumnType("datetime");

                entity.Property(e => e.ModifiedOn).HasColumnType("datetime");

                entity.Property(e => e.Notes).HasMaxLength(100);

                entity.Property(e => e.WeekDay)
                    .IsRequired()
                    .HasMaxLength(30);

                entity.HasOne(d => d.Church)
                    .WithMany(p => p.TblChurchServiceTime)
                    .HasForeignKey(d => d.ChurchId)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("FK_Tbl_ChurchServiceTime_Tbl_Church");

                entity.HasOne(d => d.CreatedByNavigation)
                    .WithMany(p => p.TblChurchServiceTimeCreatedByNavigation)
                    .HasForeignKey(d => d.CreatedBy)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("FK_Tbl_ChurchServiceTime_Tbl_User");

                entity.HasOne(d => d.ModifiedByNavigation)
                    .WithMany(p => p.TblChurchServiceTimeModifiedByNavigation)
                    .HasForeignKey(d => d.ModifiedBy)
                    .HasConstraintName("FK_Tbl_ChurchServiceTime_Tbl_User1");

                entity.HasOne(d => d.ServiceType)
                    .WithMany(p => p.TblChurchServiceTime)
                    .HasForeignKey(d => d.ServiceTypeId)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("FK_Tbl_ChurchServiceTime_Tbl_ServiceType");
            });

            modelBuilder.Entity<TblCountry>(entity =>
            {
                entity.ToTable("Tbl_Country", "Global");

                entity.Property(e => e.Id).ValueGeneratedNever();

                entity.Property(e => e.Alpha2Code).HasMaxLength(10);

                entity.Property(e => e.Alpha3Code).HasMaxLength(10);

                entity.Property(e => e.Code)
                    .HasMaxLength(4000)
                    .HasComputedColumnSql("('C'+format([CodeVal],'000'))");

                entity.Property(e => e.CreatedOn).HasColumnType("datetime");

                entity.Property(e => e.DeletedOn).HasColumnType("datetime");

                entity.Property(e => e.FrenchName).HasMaxLength(100);

                entity.Property(e => e.LastModifiedOn).HasColumnType("datetime");

                entity.Property(e => e.Name)
                    .IsRequired()
                    .HasMaxLength(100);

                entity.HasOne(d => d.CreatedByNavigation)
                    .WithMany(p => p.TblCountryCreatedByNavigation)
                    .HasForeignKey(d => d.CreatedBy)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("FK_Tbl_Country_Tbl_User");

                entity.HasOne(d => d.DeletedByNavigation)
                    .WithMany(p => p.TblCountryDeletedByNavigation)
                    .HasForeignKey(d => d.DeletedBy)
                    .HasConstraintName("FK_Tbl_Country_Tbl_User2");

                entity.HasOne(d => d.LastModifiedByNavigation)
                    .WithMany(p => p.TblCountryLastModifiedByNavigation)
                    .HasForeignKey(d => d.LastModifiedBy)
                    .HasConstraintName("FK_Tbl_Country_Tbl_User1");
            });

            modelBuilder.Entity<TblDistrict>(entity =>
            {
                entity.ToTable("Tbl_District", "Global");

                entity.Property(e => e.Id).ValueGeneratedNever();

                entity.Property(e => e.Alias).HasMaxLength(50);

                entity.Property(e => e.Code)
                    .HasMaxLength(4000)
                    .HasComputedColumnSql("('D'+format([CodeVal],'000'))");

                entity.Property(e => e.CreatedOn).HasColumnType("datetime");

                entity.Property(e => e.DeletedOn).HasColumnType("datetime");

                entity.Property(e => e.LastModifiedOn).HasColumnType("datetime");

                entity.Property(e => e.Name)
                    .IsRequired()
                    .HasMaxLength(100);

                entity.HasOne(d => d.CreatedByNavigation)
                    .WithMany(p => p.TblDistrictCreatedByNavigation)
                    .HasForeignKey(d => d.CreatedBy)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("FK_Tbl_District_Tbl_User");

                entity.HasOne(d => d.DeletedByNavigation)
                    .WithMany(p => p.TblDistrictDeletedByNavigation)
                    .HasForeignKey(d => d.DeletedBy)
                    .HasConstraintName("FK_Tbl_District_Tbl_User2");

                entity.HasOne(d => d.LastModifiedByNavigation)
                    .WithMany(p => p.TblDistrictLastModifiedByNavigation)
                    .HasForeignKey(d => d.LastModifiedBy)
                    .HasConstraintName("FK_Tbl_District_Tbl_User1");
            });

            modelBuilder.Entity<TblMacroSchedule>(entity =>
            {
                entity.ToTable("Tbl_MacroSchedule", "Global");

                entity.Property(e => e.Id).ValueGeneratedNever();

                entity.Property(e => e.CreatedOn).HasColumnType("datetime");

                entity.Property(e => e.Description).HasMaxLength(200);

                entity.Property(e => e.EntryDate).HasColumnType("datetime");

                entity.Property(e => e.ModifiedOn).HasColumnType("datetime");

                entity.HasOne(d => d.CreatedByNavigation)
                    .WithMany(p => p.TblMacroScheduleCreatedByNavigation)
                    .HasForeignKey(d => d.CreatedBy)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("FK_Tbl_MacroSchedule_Tbl_User");

                entity.HasOne(d => d.ModifiedByNavigation)
                    .WithMany(p => p.TblMacroScheduleModifiedByNavigation)
                    .HasForeignKey(d => d.ModifiedBy)
                    .HasConstraintName("FK_Tbl_MacroSchedule_Tbl_User1");
            });

            modelBuilder.Entity<TblMacroScheduleDetails>(entity =>
            {
                entity.ToTable("Tbl_MacroScheduleDetails", "Global");

                entity.Property(e => e.Id).ValueGeneratedNever();

                entity.Property(e => e.ApprovedRejectOn).HasColumnType("datetime");

                entity.Property(e => e.ApprovedRejectRemarks).HasMaxLength(100);

                entity.Property(e => e.EndDate).HasColumnType("date");

                entity.Property(e => e.Notes).HasMaxLength(100);

                entity.Property(e => e.StartDate).HasColumnType("date");

                entity.HasOne(d => d.ApprovedRejectByNavigation)
                    .WithMany(p => p.TblMacroScheduleDetailsApprovedRejectByNavigation)
                    .HasForeignKey(d => d.ApprovedRejectBy)
                    .HasConstraintName("FK_Tbl_MacroScheduleDetails_Tbl_User1");

                entity.HasOne(d => d.District)
                    .WithMany(p => p.TblMacroScheduleDetails)
                    .HasForeignKey(d => d.DistrictId)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("FK_Tbl_MacroScheduleDetails_Tbl_District");

                entity.HasOne(d => d.MacroSchedule)
                    .WithMany(p => p.TblMacroScheduleDetails)
                    .HasForeignKey(d => d.MacroScheduleId)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("FK_Tbl_MacroScheduleDetails_Tbl_MacroSchedule");

                entity.HasOne(d => d.User)
                    .WithMany(p => p.TblMacroScheduleDetailsUser)
                    .HasForeignKey(d => d.UserId)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("FK_Tbl_MacroScheduleDetails_Tbl_User");
            });

            modelBuilder.Entity<TblMenu>(entity =>
            {
                entity.ToTable("Tbl_Menu", "Auth");

                entity.Property(e => e.Id).ValueGeneratedNever();

                entity.Property(e => e.CreatedOn).HasColumnType("datetime");

                entity.Property(e => e.Icon)
                    .IsRequired()
                    .HasMaxLength(20);

                entity.Property(e => e.LastModifiedOn).HasColumnType("datetime");

                entity.Property(e => e.Name)
                    .IsRequired()
                    .HasMaxLength(100);

                entity.Property(e => e.StartingPath)
                    .IsRequired()
                    .HasMaxLength(100);

                entity.Property(e => e.Target).HasMaxLength(50);

                entity.HasOne(d => d.CreatedByNavigation)
                    .WithMany(p => p.TblMenuCreatedByNavigation)
                    .HasForeignKey(d => d.CreatedBy)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("FK_Tbl_Menu_Tbl_User");

                entity.HasOne(d => d.LastModifiedByNavigation)
                    .WithMany(p => p.TblMenuLastModifiedByNavigation)
                    .HasForeignKey(d => d.LastModifiedBy)
                    .HasConstraintName("FK_Tbl_Menu_Tbl_User1");

                entity.HasOne(d => d.MenuGroup)
                    .WithMany(p => p.TblMenu)
                    .HasForeignKey(d => d.MenuGroupId)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("FK_Tbl_Menu_Tbl_MenuGroup");
            });

            modelBuilder.Entity<TblMenuGroup>(entity =>
            {
                entity.ToTable("Tbl_MenuGroup", "Auth");

                entity.Property(e => e.Id).ValueGeneratedNever();

                entity.Property(e => e.Category).HasMaxLength(100);

                entity.Property(e => e.Icon).HasMaxLength(20);

                entity.Property(e => e.Name)
                    .IsRequired()
                    .HasMaxLength(50);

                entity.Property(e => e.Target).HasMaxLength(100);
            });

            modelBuilder.Entity<TblRole>(entity =>
            {
                entity.ToTable("Tbl_Role", "Auth");

                entity.Property(e => e.Id).ValueGeneratedNever();

                entity.Property(e => e.DataAccessCode)
                    .IsRequired()
                    .HasMaxLength(1);

                entity.Property(e => e.Name)
                    .IsRequired()
                    .HasMaxLength(50);
            });

            modelBuilder.Entity<TblRoleMenu>(entity =>
            {
                entity.HasKey(e => new { e.RoleId, e.MenuId });

                entity.ToTable("Tbl_RoleMenu", "Auth");

                entity.HasOne(d => d.Menu)
                    .WithMany(p => p.TblRoleMenu)
                    .HasForeignKey(d => d.MenuId)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("FK_Tbl_RoleMenu_Tbl_Menu");

                entity.HasOne(d => d.Role)
                    .WithMany(p => p.TblRoleMenu)
                    .HasForeignKey(d => d.RoleId)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("FK_Tbl_RoleMenu_Role");
            });

            modelBuilder.Entity<TblSection>(entity =>
            {
                entity.ToTable("Tbl_Section", "Global");

                entity.Property(e => e.Id).ValueGeneratedNever();

                entity.Property(e => e.CreatedOn).HasColumnType("datetime");

                entity.Property(e => e.DeletedOn).HasColumnType("datetime");

                entity.Property(e => e.LastModifiedOn).HasColumnType("datetime");

                entity.Property(e => e.Name)
                    .IsRequired()
                    .HasMaxLength(100);

                entity.HasOne(d => d.CreatedByNavigation)
                    .WithMany(p => p.TblSectionCreatedByNavigation)
                    .HasForeignKey(d => d.CreatedBy)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("FK_Tbl_Section_Tbl_User");

                entity.HasOne(d => d.DeletedByNavigation)
                    .WithMany(p => p.TblSectionDeletedByNavigation)
                    .HasForeignKey(d => d.DeletedBy)
                    .HasConstraintName("FK_Tbl_Section_Tbl_User2");

                entity.HasOne(d => d.District)
                    .WithMany(p => p.TblSection)
                    .HasForeignKey(d => d.DistrictId)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("FK_Tbl_Section_Tbl_District");

                entity.HasOne(d => d.LastModifiedByNavigation)
                    .WithMany(p => p.TblSectionLastModifiedByNavigation)
                    .HasForeignKey(d => d.LastModifiedBy)
                    .HasConstraintName("FK_Tbl_Section_Tbl_User1");
            });

            modelBuilder.Entity<TblServiceType>(entity =>
            {
                entity.ToTable("Tbl_ServiceType", "Global");

                entity.Property(e => e.Id).ValueGeneratedNever();

                entity.Property(e => e.CreatedOn).HasColumnType("datetime");

                entity.Property(e => e.ModifiedOn).HasColumnType("datetime");

                entity.Property(e => e.Name)
                    .IsRequired()
                    .HasMaxLength(100);

                entity.HasOne(d => d.CreatedByNavigation)
                    .WithMany(p => p.TblServiceTypeCreatedByNavigation)
                    .HasForeignKey(d => d.CreatedBy)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("FK_Tbl_ServiceType_Tbl_User");

                entity.HasOne(d => d.ModifiedByNavigation)
                    .WithMany(p => p.TblServiceTypeModifiedByNavigation)
                    .HasForeignKey(d => d.ModifiedBy)
                    .HasConstraintName("FK_Tbl_ServiceType_Tbl_User1");
            });

            modelBuilder.Entity<TblState>(entity =>
            {
                entity.ToTable("Tbl_State", "Global");

                entity.Property(e => e.Id).ValueGeneratedNever();

                entity.Property(e => e.Alias).HasMaxLength(50);

                entity.Property(e => e.Code)
                    .HasMaxLength(4000)
                    .HasComputedColumnSql("('S'+format([CodeVal],'000'))");

                entity.Property(e => e.CreatedOn).HasColumnType("datetime");

                entity.Property(e => e.DeletedOn).HasColumnType("datetime");

                entity.Property(e => e.LastModifiedOn).HasColumnType("datetime");

                entity.Property(e => e.Name)
                    .IsRequired()
                    .HasMaxLength(100);

                entity.HasOne(d => d.Country)
                    .WithMany(p => p.TblState)
                    .HasForeignKey(d => d.CountryId)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("FK_Tbl_State_Tbl_Country");

                entity.HasOne(d => d.CreatedByNavigation)
                    .WithMany(p => p.TblStateCreatedByNavigation)
                    .HasForeignKey(d => d.CreatedBy)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("FK_Tbl_State_Tbl_User");

                entity.HasOne(d => d.DeletedByNavigation)
                    .WithMany(p => p.TblStateDeletedByNavigation)
                    .HasForeignKey(d => d.DeletedBy)
                    .HasConstraintName("FK_Tbl_State_Tbl_User2");

                entity.HasOne(d => d.LastModifiedByNavigation)
                    .WithMany(p => p.TblStateLastModifiedByNavigation)
                    .HasForeignKey(d => d.LastModifiedBy)
                    .HasConstraintName("FK_Tbl_State_Tbl_User1");
            });

            modelBuilder.Entity<TblStateDistrict>(entity =>
            {
                entity.HasKey(e => new { e.DistrictId, e.StateId });

                entity.ToTable("Tbl_StateDistrict", "Global");

                entity.HasOne(d => d.District)
                    .WithMany(p => p.TblStateDistrict)
                    .HasForeignKey(d => d.DistrictId)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("FK_Tbl_StateDistrict_Tbl_District");

                entity.HasOne(d => d.State)
                    .WithMany(p => p.TblStateDistrict)
                    .HasForeignKey(d => d.StateId)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("FK_Tbl_StateDistrict_Tbl_State");
            });

            modelBuilder.Entity<TblUser>(entity =>
            {
                entity.ToTable("Tbl_User", "Auth");

                entity.Property(e => e.Id).ValueGeneratedNever();

                entity.Property(e => e.Address).HasMaxLength(200);

                entity.Property(e => e.City).HasMaxLength(50);

                entity.Property(e => e.CreatedOn).HasColumnType("datetime");

                entity.Property(e => e.Email)
                    .IsRequired()
                    .HasMaxLength(50);

                entity.Property(e => e.FirstName).HasMaxLength(50);

                entity.Property(e => e.Gender)
                    .IsRequired()
                    .HasMaxLength(20);

                entity.Property(e => e.ImageFile).HasMaxLength(100);

                entity.Property(e => e.ImageSequence).HasMaxLength(50);

                entity.Property(e => e.LastName).HasMaxLength(50);

                entity.Property(e => e.Lat).HasMaxLength(50);

                entity.Property(e => e.Long).HasMaxLength(50);

                entity.Property(e => e.MiddleName).HasMaxLength(50);

                entity.Property(e => e.Phone).HasMaxLength(50);

                entity.Property(e => e.Pincode)
                    .IsRequired()
                    .HasMaxLength(50);

                entity.Property(e => e.Status).HasMaxLength(100);

                entity.Property(e => e.TelePhoneNo).HasMaxLength(50);

                entity.Property(e => e.UserName)
                    .IsRequired()
                    .HasMaxLength(50);

                entity.Property(e => e.WorkPhoneNo).HasMaxLength(50);

                entity.HasOne(d => d.Country)
                    .WithMany(p => p.TblUser)
                    .HasForeignKey(d => d.CountryId)
                    .HasConstraintName("FK_Tbl_User_Tbl_Country");

                entity.HasOne(d => d.District)
                    .WithMany(p => p.TblUser)
                    .HasForeignKey(d => d.DistrictId)
                    .HasConstraintName("FK_Tbl_User_Tbl_District");

                entity.HasOne(d => d.Role)
                    .WithMany(p => p.TblUser)
                    .HasForeignKey(d => d.RoleId)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("FK_Tbl_User_Tbl_Role");

                entity.HasOne(d => d.Section)
                    .WithMany(p => p.TblUser)
                    .HasForeignKey(d => d.SectionId)
                    .HasConstraintName("FK_Tbl_User_Tbl_Section");
            });

            modelBuilder.Entity<TblUserAttribute>(entity =>
            {
                entity.ToTable("Tbl_UserAttribute", "Auth");

                entity.Property(e => e.Id).ValueGeneratedNever();

                entity.Property(e => e.AttributeValue).HasColumnType("numeric(18, 2)");

                entity.Property(e => e.Notes).HasMaxLength(150);

                entity.HasOne(d => d.Attribute)
                    .WithMany(p => p.TblUserAttribute)
                    .HasForeignKey(d => d.AttributeId)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("FK_Tbl_UserAttribute_Tbl_Attribute");

                entity.HasOne(d => d.User)
                    .WithMany(p => p.TblUserAttribute)
                    .HasForeignKey(d => d.UserId)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("FK_Tbl_UserAttribute_Tbl_User");
            });

            modelBuilder.Entity<TblUserChurch>(entity =>
            {
                entity.HasKey(e => new { e.UserId, e.ChurchId });

                entity.ToTable("Tbl_UserChurch", "Global");

                entity.Property(e => e.CreatedOn).HasColumnType("datetime");

                entity.Property(e => e.RelationType).HasMaxLength(50);

                entity.HasOne(d => d.Church)
                    .WithMany(p => p.TblUserChurch)
                    .HasForeignKey(d => d.ChurchId)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("FK_Tbl_UserChurch_Tbl_Church");

                entity.HasOne(d => d.User)
                    .WithMany(p => p.TblUserChurch)
                    .HasForeignKey(d => d.UserId)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("FK_Tbl_UserChurch_Tbl_User");
            });

            modelBuilder.Entity<TblUserPassword>(entity =>
            {
                entity.ToTable("Tbl_UserPassword", "Auth");

                entity.Property(e => e.Id).ValueGeneratedNever();

                entity.Property(e => e.CreatedOn).HasColumnType("datetime");

                entity.Property(e => e.Password)
                    .IsRequired()
                    .HasMaxLength(50);

                entity.HasOne(d => d.User)
                    .WithMany(p => p.TblUserPassword)
                    .HasForeignKey(d => d.UserId)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("FK_Tbl_UserPassword_Tbl_User");
            });
        }
    }
}
