﻿using System;
using System.Collections.Generic;

namespace SFA.Entities
{
    public partial class TblUserAttribute
    {
        public Guid Id { get; set; }
        public Guid UserId { get; set; }
        public Guid AttributeId { get; set; }
        public decimal? AttributeValue { get; set; }
        public string Notes { get; set; }

        public TblAttribute Attribute { get; set; }
        public TblUser User { get; set; }
    }
}
