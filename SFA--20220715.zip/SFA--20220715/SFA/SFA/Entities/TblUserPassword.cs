﻿using System;
using System.Collections.Generic;

namespace SFA.Entities
{
    public partial class TblUserPassword
    {
        public Guid Id { get; set; }
        public Guid UserId { get; set; }
        public string Password { get; set; }
        public DateTime CreatedOn { get; set; }
        public bool IsActive { get; set; }

        public TblUser User { get; set; }
    }
}
