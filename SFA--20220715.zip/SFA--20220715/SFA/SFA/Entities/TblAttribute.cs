﻿using System;
using System.Collections.Generic;

namespace SFA.Entities
{
    public partial class TblAttribute
    {
        public TblAttribute()
        {
            TblUserAttribute = new HashSet<TblUserAttribute>();
        }

        public Guid Id { get; set; }
        public string AttributeName { get; set; }
        public Guid AttributeTypeId { get; set; }
        public string AttributeNotes { get; set; }

        public TblAttributeType AttributeType { get; set; }
        public ICollection<TblUserAttribute> TblUserAttribute { get; set; }
    }
}
