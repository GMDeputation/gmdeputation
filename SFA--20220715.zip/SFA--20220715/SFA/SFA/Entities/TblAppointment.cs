﻿using System;
using System.Collections.Generic;

namespace SFA.Entities
{
    public partial class TblAppointment
    {
        public Guid Id { get; set; }
        public DateTime EventDate { get; set; }
        public TimeSpan? EventTime { get; set; }
        public Guid ChurchId { get; set; }
        public Guid? MacroScheduleDetailId { get; set; }
        public string Description { get; set; }
        public decimal? PimAmount { get; set; }
        public string Offering { get; set; }
        public string Notes { get; set; }
        public Guid CreatedBy { get; set; }
        public DateTime CreatedOn { get; set; }
        public bool IsSubmit { get; set; }
        public Guid? SubmittedBy { get; set; }
        public DateTime? SubmittedOn { get; set; }
        public string AcceptByPastorRemarks { get; set; }
        public bool IsAcceptByPastor { get; set; }
        public Guid? AcceptByPastorBy { get; set; }
        public DateTime? AcceptByPastorOn { get; set; }
        public bool IsForwardForMissionary { get; set; }
        public string AcceptMissionaryRemarks { get; set; }
        public bool IsAcceptMissionary { get; set; }
        public Guid? AcceptMissionaryBy { get; set; }
        public DateTime? AcceptMissionaryOn { get; set; }

        public TblUser AcceptByPastorByNavigation { get; set; }
        public TblUser AcceptMissionaryByNavigation { get; set; }
        public TblChurch Church { get; set; }
        public TblUser CreatedByNavigation { get; set; }
        public TblMacroScheduleDetails MacroScheduleDetail { get; set; }
        public TblUser SubmittedByNavigation { get; set; }
    }
}
