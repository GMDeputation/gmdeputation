﻿using System;
using System.Collections.Generic;

namespace SFA.Entities
{
    public partial class TblDistrict
    {
        public TblDistrict()
        {
            TblChurch = new HashSet<TblChurch>();
            TblMacroScheduleDetails = new HashSet<TblMacroScheduleDetails>();
            TblSection = new HashSet<TblSection>();
            TblStateDistrict = new HashSet<TblStateDistrict>();
            TblUser = new HashSet<TblUser>();
        }

        public Guid Id { get; set; }
        public string Code { get; set; }
        public int CodeVal { get; set; }
        public string Name { get; set; }
        public string Alias { get; set; }
        public bool IsDelete { get; set; }
        public Guid CreatedBy { get; set; }
        public DateTime CreatedOn { get; set; }
        public Guid? LastModifiedBy { get; set; }
        public DateTime? LastModifiedOn { get; set; }
        public Guid? DeletedBy { get; set; }
        public DateTime? DeletedOn { get; set; }

        public TblUser CreatedByNavigation { get; set; }
        public TblUser DeletedByNavigation { get; set; }
        public TblUser LastModifiedByNavigation { get; set; }
        public ICollection<TblChurch> TblChurch { get; set; }
        public ICollection<TblMacroScheduleDetails> TblMacroScheduleDetails { get; set; }
        public ICollection<TblSection> TblSection { get; set; }
        public ICollection<TblStateDistrict> TblStateDistrict { get; set; }
        public ICollection<TblUser> TblUser { get; set; }
    }
}
