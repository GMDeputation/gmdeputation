﻿using System;
using System.Collections.Generic;

namespace SFA.Entities
{
    public partial class TblChurchAccommodation
    {
        public Guid Id { get; set; }
        public Guid ChurchId { get; set; }
        public string AccomType { get; set; }
        public string AccomNotes { get; set; }

        public TblChurch Church { get; set; }
    }
}
