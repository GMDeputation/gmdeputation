﻿using System;
using System.Collections.Generic;

namespace SFA.Entities
{
    public partial class TblStateDistrict
    {
        public Guid DistrictId { get; set; }
        public Guid StateId { get; set; }

        public TblDistrict District { get; set; }
        public TblState State { get; set; }
    }
}
