﻿using System;
using System.Collections.Generic;

namespace SFA.Entities
{
    public partial class TblMacroSchedule
    {
        public TblMacroSchedule()
        {
            TblMacroScheduleDetails = new HashSet<TblMacroScheduleDetails>();
        }

        public Guid Id { get; set; }
        public string Description { get; set; }
        public DateTime EntryDate { get; set; }
        public bool IsActive { get; set; }
        public Guid CreatedBy { get; set; }
        public DateTime CreatedOn { get; set; }
        public Guid? ModifiedBy { get; set; }
        public DateTime? ModifiedOn { get; set; }

        public TblUser CreatedByNavigation { get; set; }
        public TblUser ModifiedByNavigation { get; set; }
        public ICollection<TblMacroScheduleDetails> TblMacroScheduleDetails { get; set; }
    }
}
