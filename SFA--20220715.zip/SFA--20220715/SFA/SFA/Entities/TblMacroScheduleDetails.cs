﻿using System;
using System.Collections.Generic;

namespace SFA.Entities
{
    public partial class TblMacroScheduleDetails
    {
        public TblMacroScheduleDetails()
        {
            TblAppointment = new HashSet<TblAppointment>();
        }

        public Guid Id { get; set; }
        public Guid MacroScheduleId { get; set; }
        public Guid DistrictId { get; set; }
        public Guid UserId { get; set; }
        public DateTime StartDate { get; set; }
        public DateTime EndDate { get; set; }
        public bool IsApproved { get; set; }
        public bool IsRejected { get; set; }
        public string Notes { get; set; }
        public string ApprovedRejectRemarks { get; set; }
        public Guid? ApprovedRejectBy { get; set; }
        public DateTime? ApprovedRejectOn { get; set; }

        public TblUser ApprovedRejectByNavigation { get; set; }
        public TblDistrict District { get; set; }
        public TblMacroSchedule MacroSchedule { get; set; }
        public TblUser User { get; set; }
        public ICollection<TblAppointment> TblAppointment { get; set; }
    }
}
