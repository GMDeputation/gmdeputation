﻿using System;
using System.Collections.Generic;

namespace SFA.Entities
{
    public partial class TblUser
    {
        public TblUser()
        {
            TblAppointmentAcceptByPastorByNavigation = new HashSet<TblAppointment>();
            TblAppointmentAcceptMissionaryByNavigation = new HashSet<TblAppointment>();
            TblAppointmentCreatedByNavigation = new HashSet<TblAppointment>();
            TblAppointmentSubmittedByNavigation = new HashSet<TblAppointment>();
            TblChurchCreatedByNavigation = new HashSet<TblChurch>();
            TblChurchDeletedByNavigation = new HashSet<TblChurch>();
            TblChurchLastModifiedByNavigation = new HashSet<TblChurch>();
            TblChurchServiceTimeCreatedByNavigation = new HashSet<TblChurchServiceTime>();
            TblChurchServiceTimeModifiedByNavigation = new HashSet<TblChurchServiceTime>();
            TblCountryCreatedByNavigation = new HashSet<TblCountry>();
            TblCountryDeletedByNavigation = new HashSet<TblCountry>();
            TblCountryLastModifiedByNavigation = new HashSet<TblCountry>();
            TblDistrictCreatedByNavigation = new HashSet<TblDistrict>();
            TblDistrictDeletedByNavigation = new HashSet<TblDistrict>();
            TblDistrictLastModifiedByNavigation = new HashSet<TblDistrict>();
            TblMacroScheduleCreatedByNavigation = new HashSet<TblMacroSchedule>();
            TblMacroScheduleDetailsApprovedRejectByNavigation = new HashSet<TblMacroScheduleDetails>();
            TblMacroScheduleDetailsUser = new HashSet<TblMacroScheduleDetails>();
            TblMacroScheduleModifiedByNavigation = new HashSet<TblMacroSchedule>();
            TblMenuCreatedByNavigation = new HashSet<TblMenu>();
            TblMenuLastModifiedByNavigation = new HashSet<TblMenu>();
            TblSectionCreatedByNavigation = new HashSet<TblSection>();
            TblSectionDeletedByNavigation = new HashSet<TblSection>();
            TblSectionLastModifiedByNavigation = new HashSet<TblSection>();
            TblServiceTypeCreatedByNavigation = new HashSet<TblServiceType>();
            TblServiceTypeModifiedByNavigation = new HashSet<TblServiceType>();
            TblStateCreatedByNavigation = new HashSet<TblState>();
            TblStateDeletedByNavigation = new HashSet<TblState>();
            TblStateLastModifiedByNavigation = new HashSet<TblState>();
            TblUserAttribute = new HashSet<TblUserAttribute>();
            TblUserChurch = new HashSet<TblUserChurch>();
            TblUserPassword = new HashSet<TblUserPassword>();
        }

        public Guid Id { get; set; }
        public string FirstName { get; set; }
        public string MiddleName { get; set; }
        public string LastName { get; set; }
        public string Phone { get; set; }
        public string UserName { get; set; }
        public string Email { get; set; }
        public string Gender { get; set; }
        public string Address { get; set; }
        public string Pincode { get; set; }
        public string Lat { get; set; }
        public string Long { get; set; }
        public Guid? SectionId { get; set; }
        public Guid? DistrictId { get; set; }
        public Guid? CountryId { get; set; }
        public bool IsEmailVerify { get; set; }
        public string ImageFile { get; set; }
        public string ImageSequence { get; set; }
        public DateTime CreatedOn { get; set; }
        public Guid RoleId { get; set; }
        public bool IsSuperAdmin { get; set; }
        public bool IsActive { get; set; }
        public string City { get; set; }
        public string WorkPhoneNo { get; set; }
        public string TelePhoneNo { get; set; }
        public string Status { get; set; }

        public TblCountry Country { get; set; }
        public TblDistrict District { get; set; }
        public TblRole Role { get; set; }
        public TblSection Section { get; set; }
        public ICollection<TblAppointment> TblAppointmentAcceptByPastorByNavigation { get; set; }
        public ICollection<TblAppointment> TblAppointmentAcceptMissionaryByNavigation { get; set; }
        public ICollection<TblAppointment> TblAppointmentCreatedByNavigation { get; set; }
        public ICollection<TblAppointment> TblAppointmentSubmittedByNavigation { get; set; }
        public ICollection<TblChurch> TblChurchCreatedByNavigation { get; set; }
        public ICollection<TblChurch> TblChurchDeletedByNavigation { get; set; }
        public ICollection<TblChurch> TblChurchLastModifiedByNavigation { get; set; }
        public ICollection<TblChurchServiceTime> TblChurchServiceTimeCreatedByNavigation { get; set; }
        public ICollection<TblChurchServiceTime> TblChurchServiceTimeModifiedByNavigation { get; set; }
        public ICollection<TblCountry> TblCountryCreatedByNavigation { get; set; }
        public ICollection<TblCountry> TblCountryDeletedByNavigation { get; set; }
        public ICollection<TblCountry> TblCountryLastModifiedByNavigation { get; set; }
        public ICollection<TblDistrict> TblDistrictCreatedByNavigation { get; set; }
        public ICollection<TblDistrict> TblDistrictDeletedByNavigation { get; set; }
        public ICollection<TblDistrict> TblDistrictLastModifiedByNavigation { get; set; }
        public ICollection<TblMacroSchedule> TblMacroScheduleCreatedByNavigation { get; set; }
        public ICollection<TblMacroScheduleDetails> TblMacroScheduleDetailsApprovedRejectByNavigation { get; set; }
        public ICollection<TblMacroScheduleDetails> TblMacroScheduleDetailsUser { get; set; }
        public ICollection<TblMacroSchedule> TblMacroScheduleModifiedByNavigation { get; set; }
        public ICollection<TblMenu> TblMenuCreatedByNavigation { get; set; }
        public ICollection<TblMenu> TblMenuLastModifiedByNavigation { get; set; }
        public ICollection<TblSection> TblSectionCreatedByNavigation { get; set; }
        public ICollection<TblSection> TblSectionDeletedByNavigation { get; set; }
        public ICollection<TblSection> TblSectionLastModifiedByNavigation { get; set; }
        public ICollection<TblServiceType> TblServiceTypeCreatedByNavigation { get; set; }
        public ICollection<TblServiceType> TblServiceTypeModifiedByNavigation { get; set; }
        public ICollection<TblState> TblStateCreatedByNavigation { get; set; }
        public ICollection<TblState> TblStateDeletedByNavigation { get; set; }
        public ICollection<TblState> TblStateLastModifiedByNavigation { get; set; }
        public ICollection<TblUserAttribute> TblUserAttribute { get; set; }
        public ICollection<TblUserChurch> TblUserChurch { get; set; }
        public ICollection<TblUserPassword> TblUserPassword { get; set; }
    }
}
