﻿using System;
using System.Collections.Generic;

namespace SFA.Entities
{
    public partial class TblAttributeType
    {
        public TblAttributeType()
        {
            TblAttribute = new HashSet<TblAttribute>();
        }

        public Guid Id { get; set; }
        public string Name { get; set; }

        public ICollection<TblAttribute> TblAttribute { get; set; }
    }
}
