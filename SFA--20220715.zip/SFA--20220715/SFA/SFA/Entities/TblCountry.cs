﻿using System;
using System.Collections.Generic;

namespace SFA.Entities
{
    public partial class TblCountry
    {
        public TblCountry()
        {
            TblState = new HashSet<TblState>();
            TblUser = new HashSet<TblUser>();
        }

        public Guid Id { get; set; }
        public string Code { get; set; }
        public int CodeVal { get; set; }
        public string Name { get; set; }
        public string FrenchName { get; set; }
        public string Alpha2Code { get; set; }
        public string Alpha3Code { get; set; }
        public bool IsDelete { get; set; }
        public Guid CreatedBy { get; set; }
        public DateTime CreatedOn { get; set; }
        public Guid? LastModifiedBy { get; set; }
        public DateTime? LastModifiedOn { get; set; }
        public Guid? DeletedBy { get; set; }
        public DateTime? DeletedOn { get; set; }

        public TblUser CreatedByNavigation { get; set; }
        public TblUser DeletedByNavigation { get; set; }
        public TblUser LastModifiedByNavigation { get; set; }
        public ICollection<TblState> TblState { get; set; }
        public ICollection<TblUser> TblUser { get; set; }
    }
}
