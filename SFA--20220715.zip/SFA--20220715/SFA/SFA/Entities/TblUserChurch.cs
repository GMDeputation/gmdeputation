﻿using System;
using System.Collections.Generic;

namespace SFA.Entities
{
    public partial class TblUserChurch
    {
        public Guid UserId { get; set; }
        public Guid ChurchId { get; set; }
        public DateTime CreatedOn { get; set; }
        public string RelationType { get; set; }

        public TblChurch Church { get; set; }
        public TblUser User { get; set; }
    }
}
