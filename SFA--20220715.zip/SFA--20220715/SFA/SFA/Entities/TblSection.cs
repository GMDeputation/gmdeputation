﻿using System;
using System.Collections.Generic;

namespace SFA.Entities
{
    public partial class TblSection
    {
        public TblSection()
        {
            TblChurch = new HashSet<TblChurch>();
            TblUser = new HashSet<TblUser>();
        }

        public Guid Id { get; set; }
        public string Name { get; set; }
        public Guid DistrictId { get; set; }
        public bool IsDelete { get; set; }
        public Guid CreatedBy { get; set; }
        public DateTime CreatedOn { get; set; }
        public Guid? LastModifiedBy { get; set; }
        public DateTime? LastModifiedOn { get; set; }
        public Guid? DeletedBy { get; set; }
        public DateTime? DeletedOn { get; set; }

        public TblUser CreatedByNavigation { get; set; }
        public TblUser DeletedByNavigation { get; set; }
        public TblDistrict District { get; set; }
        public TblUser LastModifiedByNavigation { get; set; }
        public ICollection<TblChurch> TblChurch { get; set; }
        public ICollection<TblUser> TblUser { get; set; }
    }
}
