﻿using System;
using System.Collections.Generic;

namespace SFA.Entities
{
    public partial class TblServiceType
    {
        public TblServiceType()
        {
            TblChurchServiceTime = new HashSet<TblChurchServiceTime>();
        }

        public Guid Id { get; set; }
        public string Name { get; set; }
        public bool IsDelete { get; set; }
        public Guid CreatedBy { get; set; }
        public DateTime CreatedOn { get; set; }
        public Guid? ModifiedBy { get; set; }
        public DateTime? ModifiedOn { get; set; }

        public TblUser CreatedByNavigation { get; set; }
        public TblUser ModifiedByNavigation { get; set; }
        public ICollection<TblChurchServiceTime> TblChurchServiceTime { get; set; }
    }
}
