﻿using System;
using System.Collections.Generic;

namespace SFA.Entities
{
    public partial class TblState
    {
        public TblState()
        {
            TblStateDistrict = new HashSet<TblStateDistrict>();
        }

        public Guid Id { get; set; }
        public string Code { get; set; }
        public int CodeVal { get; set; }
        public string Alias { get; set; }
        public string Name { get; set; }
        public Guid CountryId { get; set; }
        public bool IsDelete { get; set; }
        public Guid CreatedBy { get; set; }
        public DateTime CreatedOn { get; set; }
        public Guid? LastModifiedBy { get; set; }
        public DateTime? LastModifiedOn { get; set; }
        public Guid? DeletedBy { get; set; }
        public DateTime? DeletedOn { get; set; }

        public TblCountry Country { get; set; }
        public TblUser CreatedByNavigation { get; set; }
        public TblUser DeletedByNavigation { get; set; }
        public TblUser LastModifiedByNavigation { get; set; }
        public ICollection<TblStateDistrict> TblStateDistrict { get; set; }
    }
}
