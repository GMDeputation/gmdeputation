﻿using System;
using System.Collections.Generic;

namespace SFA.Entities
{
    public partial class TblChurchServiceTime
    {
        public Guid Id { get; set; }
        public Guid ChurchId { get; set; }
        public string WeekDay { get; set; }
        public TimeSpan ServiceTime { get; set; }
        public Guid ServiceTypeId { get; set; }
        public int Preferencelevel { get; set; }
        public string Notes { get; set; }
        public Guid CreatedBy { get; set; }
        public DateTime CreatedOn { get; set; }
        public Guid? ModifiedBy { get; set; }
        public DateTime? ModifiedOn { get; set; }

        public TblChurch Church { get; set; }
        public TblUser CreatedByNavigation { get; set; }
        public TblUser ModifiedByNavigation { get; set; }
        public TblServiceType ServiceType { get; set; }
    }
}
