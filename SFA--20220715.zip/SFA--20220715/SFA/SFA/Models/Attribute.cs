﻿using Newtonsoft.Json;
using System;
using System.Collections.Generic;

namespace SFA.Models
{
    public class AttributeModel
    {
        public Guid Id { get; set; }
        public string AttributeName { get; set; }
        public Guid AttributeTypeId { get; set; }
        public string AttributeTypeName { get; set; }
        public string AttributeNotes { get; set; }
    }

    public class AttributeTypeModel
    {
        public Guid Id { get; set; }
        public string Name { get; set; }

        public List<AttributeModel> Attributes { get; set; }
    }

    public class AttributeModelQuery : Query
    {
        public string Name { get; set; }
    }
}