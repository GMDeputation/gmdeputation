﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace SFA.Models
{
    public class Appointment
    {
        public Guid Id { get; set; }
        public DateTime EventDate { get; set; }
        public TimeSpan? EventTime { get; set; }
        public Guid ChurchId { get; set; }
        public string ChurchName { get; set; }
        public Guid? MacroScheduleDetailId { get; set; }
        public string Description { get; set; }
        public decimal? PimAmount { get; set; }
        public string Offering { get; set; }
        public string Notes { get; set; }
        public Guid CreatedBy { get; set; }
        public DateTime CreatedOn { get; set; }
        public bool IsSubmit { get; set; }
        public Guid? SubmittedBy { get; set; }
        public DateTime? SubmittedOn { get; set; }
        public bool IsAcceptByPastor { get; set; }
        public string AcceptByPastorRemarks { get; set; }
        public Guid? AcceptByPastorBy { get; set; }
        public DateTime? AcceptByPastorOn { get; set; }
        public bool IsForwardForMissionary { get; set; }
        public bool IsAcceptMissionary { get; set; }
        public string AcceptMissionaryRemarks { get; set; }
        public Guid? AcceptMissionaryBy { get; set; }
        public DateTime? AcceptMissionaryOn { get; set; }

        public string Status { get; set; }
        public string TimeString { get; set; }
        public string AccessCode { get; set; } 
        public string DistrictName { get; set; } 
        public string MacroScheduleDesc { get; set; } 
        public string MissionaryUser { get; set; } 
    }

    public class AppointmentQuery : Query
    {
        public string Filter { get; set; }
        public DateTime? FromDate { get; set; }
        public DateTime? ToDate { get; set; } 
    }
}
