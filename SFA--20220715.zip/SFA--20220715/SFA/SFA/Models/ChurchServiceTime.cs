﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace SFA.Models
{
    public class ChurchServiceTime
    {
        public Guid Id { get; set; }
        public Guid ChurchId { get; set; }
        public string ChurchName { get; set; }
        public string WeekDay { get; set; }
        public TimeSpan ServiceTime { get; set; }
        public Guid ServiceTypeId { get; set; }
        public string ServiceTypeName { get; set; }
        public int Preferencelevel { get; set; }
        public string Notes { get; set; }
        public Guid CreatedBy { get; set; }
        public DateTime CreatedOn { get; set; }
        public Guid? ModifiedBy { get; set; }
        public DateTime? ModifiedOn { get; set; }

        public string TimeString { get; set; }
    }

    public class ChurchServiceTimeQuery : Query
    {
        public string Filter { get; set; }
        public List<Guid> ServiceTypeId { get; set; }
        public Guid? ChurchId { get; set; }
        public List<string> WeekDay { get; set; }
        public TimeSpan? StartTime { get; set; }
        public TimeSpan? EndTime { get; set; } 
    }
}
