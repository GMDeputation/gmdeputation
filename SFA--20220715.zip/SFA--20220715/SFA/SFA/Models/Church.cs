﻿using Newtonsoft.Json;
using System;

namespace SFA.Models
{
    public class Church
    {
        public Guid Id { get; set; }
        public string ChurchName { get; set; }
        public string Address { get; set; }
        public string Directory { get; set; }
        public string MailAddress { get; set; }
        public string ChurchType { get; set; }
        public string AccountNo { get; set; }
        public string Lat { get; set; }
        public string Lon { get; set; }
        public Guid SectionId { get; set; }
        public string SectionName { get; set; }
        public Guid DistrictId { get; set; }
        public string DistrictName { get; set; } 
        public string Phone { get; set; }
        public string Phone2 { get; set; }
        public string Email { get; set; }
        public string WebSite { get; set; }
        public string Status { get; set; }
        public bool IsDelete { get; set; }
        public Guid CreatedBy { get; set; }
        public DateTime CreatedOn { get; set; }
        public Guid? LastModifiedBy { get; set; }
        public DateTime? LastModifiedOn { get; set; }
        public Guid? DeletedBy { get; set; }
        public DateTime? DeletedOn { get; set; }
        public string Pastor { get; set; }
    }
    public class ChurchQuery : Query
    {
        public string Filter { get; set; }
        public Guid DistrictId { get; set; }
        public Guid SectionId { get; set; }
        public string Email { get; set; }
    }
}