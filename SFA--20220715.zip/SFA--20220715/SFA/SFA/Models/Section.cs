﻿using Newtonsoft.Json;
using System;

namespace SFA.Models
{
    public class Section
    {
        public Guid Id { get; set; }
        public string Code { get; set; }
        public int CodeVal { get; set; }
        public string Name { get; set; }
        public Guid DistrictId { get; set; }
        public string DistrictName { get; set; }
        public Guid StateId { get; set; }
        public string StateName { get; set; }
        public Guid CountryId { get; set; }
        public string CountryName { get; set; }
        public bool IsDelete { get; set; }
        public Guid CreatedBy { get; set; }
        public DateTime CreatedOn { get; set; }
        public Guid? LastModifiedBy { get; set; }
        public DateTime? LastModifiedOn { get; set; }
        public Guid? DeletedBy { get; set; }
        public DateTime? DeletedOn { get; set; }
    }
    public class SectionQuery : Query
    {
        public string Filter { get; set; }
        public Guid CountryId { get; set; }
        public Guid StateId { get; set; }
        public Guid DistrictId { get; set; }
    }
}
