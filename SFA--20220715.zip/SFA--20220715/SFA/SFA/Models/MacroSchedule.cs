﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace SFA.Models
{
    public class MacroSchedule
    {
        public Guid Id { get; set; }
        public string Description { get; set; }
        public bool IsActive { get; set; }
        public DateTime EntryDate { get; set; }
        public Guid CreatedBy { get; set; }
        public DateTime CreatedOn { get; set; }
        public Guid? ModifiedBy { get; set; }
        public DateTime? ModifiedOn { get; set; }

        public List<MacroScheduleDetails> MacroScheduleDetails { get; set; }
    }

    public class MacroScheduleDetails
    {
        public Guid Id { get; set; }
        public Guid MacroScheduleId { get; set; }
        public string MacroScheduleDesc { get; set; }
        public Guid DistrictId { get; set; }
        public string DistrictName { get; set; }
        public Guid UserId { get; set; }
        public string UserName { get; set; }
        public DateTime StartDate { get; set; }
        public DateTime EndDate { get; set; }
        public bool IsApproved { get; set; }
        public bool IsRejected { get; set; }
        public string Notes { get; set; }
        public string ApprovedRejectRemarks { get; set; }
        public Guid ApprovedRejectBy { get; set; }
        public DateTime ApprovedRejectOn { get; set; }

        public string Status { get; set; }
        public string AccessCode { get; set; } 
        public bool IsDateOver { get; set; }

        public DateTime? EntryDate { get; set; }
        public string ApprovedRejectUser { get; set; } 
    }

    public class MacroScheduleQuery : Query
    {
        public string Filter { get; set; }
        public DateTime? FromDate { get; set; }
        public DateTime? ToDate { get; set; }
        public DateTime? FromEntryDate { get; set; }
        public DateTime? ToEntryDate { get; set; } 
    }
}
