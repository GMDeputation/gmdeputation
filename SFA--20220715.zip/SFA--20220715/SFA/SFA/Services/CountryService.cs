﻿using SFA.Models;
using SFA.Entities;
using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace SFA.Services
{
    public interface ICountryService
    {
        Task<List<Country>> GetAll();
        Task<Country> GetById(Guid id);
        Task<QueryResult<Country>> Search(CountryQuery query);
        Task<string> Add(Country country);
        Task<string> Edit(Country country);
        Task<bool> Delete(Guid id,Guid userId);
        //Task<QueryResult<Country>> Search(CountryQuery query);
    }

    public class CountryService : ICountryService
    {
        private readonly SFADBContext _context = null;

        public CountryService(SFADBContext context)
        {
            _context = context;
        }

        public async Task<List<Country>> GetAll()
        {
            var countryEntities = await _context.TblCountry.Where(m=> !m.IsDelete).OrderBy(m => m.Name).ToListAsync();
            return countryEntities.Select(m => new Country
            {
                Id = m.Id,
                Code = m.Code,
                Name = m.Name
            }).ToList();
        }
        public async Task<Country> GetById(Guid id)
        {
            var countryEntity = await _context.TblCountry.FirstOrDefaultAsync(m => m.Id == id && !m.IsDelete);
            return countryEntity == null ? null : new Country
            {
                Id = countryEntity.Id,
                Code = countryEntity.Code,
                Name = countryEntity.Name,
                Alpha2Code = countryEntity.Alpha2Code,
                Alpha3Code = countryEntity.Alpha3Code,
                FrenchName = countryEntity.FrenchName
            };
        }

        public async Task<QueryResult<Country>> Search(CountryQuery query)
        {
            try
            {
                var skip = (query.Page - 1) * query.Limit;
                var countryQuery = _context.TblCountry.Where(m => !m.IsDelete).AsNoTracking().AsQueryable();
                if (!string.IsNullOrEmpty(query.Filter))
                {
                    countryQuery = countryQuery.Where(m => m.Name.Contains(query.Filter) || m.Alpha2Code.Contains(query.Filter) || m.Alpha3Code.Contains(query.Filter));
                }
                var count = await countryQuery.CountAsync();

                switch (query.Order.ToLower())
                {
                    default:
                        countryQuery = query.Order.StartsWith("-") ? countryQuery.OrderByDescending(m => m.Name) : countryQuery.OrderBy(m => m.Name);
                        break;
                }
                var stateEntities = await countryQuery.Skip(skip).Take(query.Limit).ToListAsync();
                var countries = stateEntities.Select(m => new Country
                {
                    Id = m.Id,
                    Name = m.Name,
                    Alpha2Code = m.Alpha2Code,
                    Alpha3Code = m.Alpha3Code,
                    FrenchName = m.FrenchName,
                    Code = m.Code
                }).ToList();

                return new QueryResult<Country> { Result = countries, Count = count };
            }
            catch (Exception)
            {
                return null;
            }
        }

        public async Task<string> Add(Country country)
        {
            var entity = await _context.TblCountry.FirstOrDefaultAsync(m => (m.Name == country.Name) && !m.IsDelete);
            var maxEntity = await _context.TblCountry.OrderByDescending(m => m.CodeVal).FirstOrDefaultAsync();
            var maxNumber = 1;
            if(maxEntity != null)
            {
                maxNumber = maxEntity.CodeVal + 1;
            }
            if(entity!=null)
            {
                
                return "Country name is already exists.Kindly change country name";
            }
            var countryEntity = new TblCountry
            {
                Id = Guid.NewGuid(),
                CodeVal = maxNumber,
                Name = country.Name,
                Alpha2Code = country.Alpha2Code,
                Alpha3Code = country.Alpha3Code,
                FrenchName = country.FrenchName,
                IsDelete = false,
                CreatedBy = country.CreatedBy,
                CreatedOn = DateTime.Now
            };

            try
            {
                _context.TblCountry.Add(countryEntity);
                await _context.SaveChangesAsync();
                return "";
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }
        public async Task<string> Edit(Country country)
        {
            var entity = await _context.TblCountry.FirstOrDefaultAsync(m => (m.Name == country.Name) && m.Id != country.Id && !m.IsDelete);
            if (entity != null)
            {
                
                return "Country name is already exists.Kindly change country name";
                
            }
            var countryEntity = await _context.TblCountry.FirstOrDefaultAsync(m => m.Id == country.Id);
            countryEntity.Name = country.Name;
            countryEntity.Alpha2Code = country.Alpha2Code;
            countryEntity.Alpha3Code = country.Alpha3Code;
            countryEntity.FrenchName = country.FrenchName;
            countryEntity.LastModifiedBy = country.LastModifiedBy;
            countryEntity.LastModifiedOn = DateTime.Now;

            try
            {
                await _context.SaveChangesAsync();
                return "";
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }
        public async Task<bool> Delete(Guid id,Guid userId)
        {
            var countryEntity = await _context.TblCountry.FirstOrDefaultAsync(m => m.Id == id);
            countryEntity.IsDelete = true;
            countryEntity.DeletedBy = userId;
            countryEntity.DeletedOn = DateTime.Now;

            try
            {
                await _context.SaveChangesAsync();
                return true;
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }
    }
}