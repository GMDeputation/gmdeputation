﻿using SFA.Models;
using SFA.Entities;
using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace SFA.Services
{
    public interface IDistrictService
    {
        Task<List<District>> GetAll();
        Task<District> GetById(Guid id);
        Task<List<District>> GetDistricByStateId(Guid id);
        Task<QueryResult<District>> Search(DistrictQuery query);
        Task<string> Add(District district);
        Task<string> Edit(District district);
        Task<bool> Delete(Guid id,Guid userId);
    }
    public class DistrictService : IDistrictService
    {
        private readonly SFADBContext _context = null;

        public DistrictService(SFADBContext context)
        {
            _context = context;
        }

        public async Task<List<District>> GetAll()
        {
            var districtEntities = await _context.TblDistrict.Where(m=>!m.IsDelete).OrderBy(m => m.Name).ToListAsync();
            return districtEntities.Select(m => new District
            {
                Id = m.Id,
                Code = m.Code,
                Name = m.Name,
                Alias = m.Alias
            }).ToList();
        }
        public async Task<District> GetById(Guid id)
        {
            var districtEntities = await _context.TblDistrict.FirstOrDefaultAsync(m => m.Id == id && !m.IsDelete);
            var stateEntities = await _context.TblStateDistrict.Include(m => m.State).Where(m => m.DistrictId == id && !m.State.IsDelete).OrderBy(m=>m.State.Name).ToListAsync();
            return districtEntities == null ? null : new District
            {
                Id = districtEntities.Id,
                Code = districtEntities.Code,
                Name = districtEntities.Name,
                Alias = districtEntities.Alias,
                States = stateEntities.Select(m=> new State
                {
                    Id = m.State.Id,
                    Name = m.State.Name+"( " + m.State.Alias + " )"
                }).ToList()
            };
        }
        public async Task<List<District>> GetDistricByStateId(Guid id)
        {
            var districtEntities = await _context.TblStateDistrict.Include(m=>m.District).Where(a => a.StateId == id && !a.District.IsDelete).ToListAsync();
            return districtEntities.Select(a => new District
            {
                Id = a.District.Id,
                Name = a.District.Name
            }).OrderBy(a => a.Name).ToList();
        }
        public async Task<QueryResult<District>> Search(DistrictQuery query)
        {
            try
            {
                var skip = (query.Page - 1) * query.Limit;
                var districtQuery = _context.TblDistrict.Include(m => m.TblUser).ThenInclude(m => m.Role).Where(m=> !m.IsDelete).AsNoTracking().AsQueryable();

                //if (query.CountryId != Guid.Empty)
                //{
                //    districtQuery = districtQuery.Where(m => m.TblStateDistrict.State.CountryId == query.CountryId);
                //}
                //if (query.StateId != Guid.Empty)
                //{
                //    districtQuery = districtQuery.Where(m => m.StateId == query.StateId);
                //}
                if (!string.IsNullOrEmpty(query.Filter))
                {
                    districtQuery = districtQuery.Where(m => m.Name.Contains(query.Filter) || m.Code.Contains(query.Filter) || m.Alias.Contains(query.Filter));
                }
                var count = await districtQuery.CountAsync();

                switch (query.Order.ToLower())
                {
                    case "code":
                        districtQuery = districtQuery.OrderBy(m => m.Code);
                        break;
                    case "-code":
                        districtQuery = districtQuery.OrderByDescending(m => m.Code);
                        break;
                    case "alias":
                        districtQuery = districtQuery.OrderBy(m => m.Alias);
                        break;
                    case "-alias":
                        districtQuery = districtQuery.OrderByDescending(m => m.Alias);
                        break;
                    default:
                        districtQuery = query.Order.StartsWith("-") ? districtQuery.OrderByDescending(m => m.Name) : districtQuery.OrderBy(m => m.Name);
                        break;
                }
                var districtEntities = await districtQuery.Skip(skip).Take(query.Limit).ToListAsync();
                //var stat
                var districts = districtEntities.Select(m => new District
                {
                    Id = m.Id,
                    Name = m.Name,
                    Code = m.Code,
                    Alias = m.Alias,
                    DGMDUserName = m.TblUser.Count() > 0 ? m.TblUser.Where(n => n.Role.DataAccessCode == "D").FirstOrDefault()?.FirstName + "  " + m.TblUser.Where(n => n.Role.DataAccessCode == "D").FirstOrDefault()?.LastName : null,
                    SGMDUserName = m.TblUser.Count() > 0 ? m.TblUser.Where(n => n.Role.DataAccessCode == "S").FirstOrDefault()?.FirstName + "  " + m.TblUser.Where(n => n.Role.DataAccessCode == "S").FirstOrDefault()?.LastName : null
                    //CountryId = m.State.CountryId,
                    //CountryName = m.State.Country.Name,
                    //StateName = m.State.Name,
                    //StateId = m.StateId
                }).ToList();

                return new QueryResult<District> { Result = districts, Count = count };
            }
            catch
            {
                return null;
            }
        }
        public async Task<string> Add(District district)
        {
            var entity = await _context.TblDistrict.FirstOrDefaultAsync(m => (m.Name == district.Name) && !m.IsDelete);
            var maxEntity = await _context.TblDistrict.OrderByDescending(m => m.CodeVal).FirstOrDefaultAsync();
            var maxNumber = 1;
            var districtId = Guid.NewGuid();
            if (maxEntity != null)
            {
                maxNumber = maxEntity.CodeVal + 1;
            }
            if (entity != null)
            {
                return "District name is already exists.Kindly change district name";
            }
            var districtEntities = new TblDistrict
            {
                Id = districtId,
                CodeVal = maxNumber,
                Alias = district.Alias,
                Name = district.Name,
                //StateId = district.StateId,
                IsDelete = false,
                CreatedBy = district.CreatedBy,
                CreatedOn = DateTime.Now
            };

            if(district.States!= null)
            {
                var districtStateEntities = district.States.Select(m => new TblStateDistrict
                {
                    DistrictId = districtId,
                    StateId = m.Id
                }).ToList();

                _context.TblStateDistrict.AddRange(districtStateEntities);
            }

            

            try
            {
                _context.TblDistrict.Add(districtEntities);
                
                await _context.SaveChangesAsync();
                return "";
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }
        public async Task<string> Edit(District district)
        {
            var entity = await _context.TblDistrict.FirstOrDefaultAsync(m => (m.Name == district.Name) && m.Id != district.Id && !m.IsDelete);
            if (entity != null)
            {
                return "District name is already exists.Kindly change district name";
            }
            var districtEntities = await _context.TblDistrict.Include(m=>m.TblStateDistrict).FirstOrDefaultAsync(m => m.Id == district.Id);
            districtEntities.Name = district.Name;
            //districtEntities.Code = district.Code;
            //districtEntities.StateId = district.StateId;
            districtEntities.Alias = district.Alias;
            districtEntities.LastModifiedBy = district.LastModifiedBy;
            districtEntities.LastModifiedOn = DateTime.Now;

            try
            {
                _context.TblStateDistrict.RemoveRange(districtEntities.TblStateDistrict);

                await _context.SaveChangesAsync();
                var districtStateEntities = district.States.Select(m => new TblStateDistrict
                {
                    DistrictId = district.Id,
                    StateId = m.Id
                }).ToList();

                await _context.TblStateDistrict.AddRangeAsync(districtStateEntities);

                await _context.SaveChangesAsync();

                return "";
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }
        public async Task<bool> Delete(Guid id,Guid userId)
        {
            var districtEntities = await _context.TblDistrict.FirstOrDefaultAsync(m => m.Id == id);
            districtEntities.IsDelete = true;
            districtEntities.DeletedBy = userId;
            districtEntities.DeletedOn = DateTime.Now;

            try
            {
                await _context.SaveChangesAsync();
                return true;
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }
    }
}
