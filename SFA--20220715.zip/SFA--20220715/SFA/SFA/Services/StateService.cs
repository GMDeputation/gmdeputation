﻿using SFA.Models;
using SFA.Entities;
using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace SFA.Services
{
    public interface IStateService
    {
        Task<List<State>> GetAll();
        Task<State> GetById(Guid id);
        Task<List<State>> GetStateByCountryId(Guid id);
        Task<QueryResult<State>> Search(StateQuery query);
        Task<string> Add(State state);
        Task<string> Edit(State state);
        Task<bool> Delete(Guid id,Guid userId);
    }
    public class StateService : IStateService
    {
        private readonly SFADBContext _context = null;

        public StateService(SFADBContext context)
        {
            _context = context;
        }

        public async Task<List<State>> GetAll()
        {
            var stateEntities = await _context.TblState.Include(m => m.Country).Where(m=>!m.IsDelete).OrderBy(m => m.Name).ToListAsync();
            return stateEntities.Select(m => new State
            {
                Id = m.Id,
                Code = m.Code,
                Name = m.Name + "( " + m.Alias + " )",
                Alias = m.Alias,
                CountryName = m.Country.Name
            }).ToList();
        }
        public async Task<State> GetById(Guid id)
        {
            var stateEntities = await _context.TblState.FirstOrDefaultAsync(m => m.Id == id && !m.IsDelete);
            return stateEntities == null ? null : new State
            {
                Id = stateEntities.Id,
                Code = stateEntities.Code,
                Name = stateEntities.Name,
                Alias = stateEntities.Alias,
                CountryId = stateEntities.CountryId
            };
        }
        public async Task<List<State>> GetStateByCountryId(Guid id)
        {
            var stateEntities = await _context.TblState.Where(a => a.CountryId == id && !a.IsDelete).ToListAsync();
            return stateEntities.Select(a => new State
            {
                Id = a.Id,
                Name = a.Name,
                Code = a.Code,
                Alias = a.Alias,
            }).OrderBy(a => a.Name).ToList();
        }
        public async Task<QueryResult<State>> Search(StateQuery query)
        {
            try
            {
                var skip = (query.Page - 1) * query.Limit;
                var stateQuery = _context.TblState.Include(m => m.Country).Where(m=> !m.IsDelete).AsNoTracking().AsQueryable();

                if (query.CountryId != Guid.Empty)
                {
                    stateQuery = stateQuery.Where(m => m.CountryId == query.CountryId);
                }
                if (!string.IsNullOrEmpty(query.Filter))
                {
                    stateQuery = stateQuery.Where(m => m.Name.Contains(query.Filter));
                }
                var count = await stateQuery.CountAsync();

                switch (query.Order.ToLower())
                {
                    default:
                        stateQuery = query.Order.StartsWith("-") ? stateQuery.OrderByDescending(m => m.Name) : stateQuery.OrderBy(m => m.Name);
                        break;
                }
                var stateEntities = await stateQuery.Skip(skip).Take(query.Limit).ToListAsync();
                var states = stateEntities.Select(m => new State
                {
                    Id = m.Id,
                    Name = m.Name,
                    Alias = m.Alias,
                    Code = m.Code,
                    CountryId = m.CountryId,
                    CountryName = m.Country.Name
                }).ToList();

                return new QueryResult<State> { Result = states, Count = count };
            }
            catch (Exception)
            {
                return null;
            }
        }
        public async Task<string> Add(State state)
        {
            var entity = await _context.TblState.FirstOrDefaultAsync(m => (m.Name == state.Name) && !m.IsDelete);
            var maxEntity = await _context.TblState.OrderByDescending(m => m.CodeVal).FirstOrDefaultAsync();
            var maxNumber = 1;
            if (maxEntity != null)
            {
                maxNumber = maxEntity.CodeVal + 1;
            }
            if (entity != null)
            {
                
                    return "State name is already exists.Kindly change state name";
                
            }
            var stateEntities = new TblState
            {
                Id = Guid.NewGuid(),
                CodeVal = maxNumber,
                Name = state.Name,
                Alias = state.Alias,
                IsDelete = false,
                CountryId = state.CountryId,
                CreatedBy = state.CreatedBy,
                CreatedOn = DateTime.Now
            };

            try
            {
                _context.TblState.Add(stateEntities);
                await _context.SaveChangesAsync();
                return "";
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }
        public async Task<string> Edit(State state)
        {
            var entity = await _context.TblState.FirstOrDefaultAsync(m => (m.Name == state.Name) && m.Id != state.Id && !m.IsDelete);
            if (entity != null)
            {
                return "State name is already exists.Kindly change state name";   
            }
            var stateEntities = await _context.TblState.FirstOrDefaultAsync(m => m.Id == state.Id);
            stateEntities.Name = state.Name;
            stateEntities.Alias = state.Alias;
            //stateEntities.Code = state.Code;
            stateEntities.CountryId = state.CountryId;
            stateEntities.LastModifiedBy = state.LastModifiedBy;
            stateEntities.LastModifiedOn = DateTime.Now;

            try
            {
                await _context.SaveChangesAsync();
                return "";
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }
        public async Task<bool> Delete(Guid id,Guid userId)
        {
            var stateEntities = await _context.TblState.FirstOrDefaultAsync(m => m.Id == id);
            stateEntities.IsDelete = true;
            stateEntities.DeletedBy = userId;
            stateEntities.DeletedOn = DateTime.Now;

            try
            {
                await _context.SaveChangesAsync();
                return true;
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }
    }
}
