﻿using Microsoft.EntityFrameworkCore;
using SFA.Entities;
using SFA.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace SFA.Services
{
    public interface IUserService
    {
        Task<List<User>> GetAll();
        Task<User> GetById(Guid id);
        Task<List<User>> GetByRoleId(Guid roleId);
        Task<QueryResult<User>> Search(UserQuery query);
        Task<bool> ChangePassword(Guid userId, User user);
        Task<int> Save(User user);
        Task<User> Validate(string email, string password);
        Task<List<RoleMenu>> GetMenuByUser(Guid userId);
        //Task<List<ApplicationAccess>> GetAccessList(Guid id);
        //Task<List<UserApplication>> GetMenuByUser(Guid userId);
        //Task<bool> SaveLogIn(Guid id);
        //Task<bool> SaveLogOut(Guid id);

        Task<List<User>> GetAllMissionariesUser();
    }

    public class UserService : IUserService
    {
        private readonly SFADBContext _context = null;
        private readonly IMenuService _menuService = null;
        private readonly IMenuGroupService _menuGroupService = null;

        public UserService(SFADBContext context, IMenuService menuService, IMenuGroupService menuGroupService)
        {
            _context = context;
            _menuService = menuService;
            _menuGroupService = menuGroupService;
        }

        public async Task<bool> ChangePassword(Guid userId, User user)
        {
            var userEntity = await _context.TblUser.FirstOrDefaultAsync(m => m.Id == userId);

            if (userEntity == null)
            {
                return false;
            }

            var passwordEntity = new TblUserPassword
            {
                Id = Guid.NewGuid(),
                CreatedOn = DateTime.Now,
                Password = user.NewPassword,
                UserId = userId,
                IsActive = true
            };
            try
            {
                _context.TblUserPassword.Add(passwordEntity);
                await _context.SaveChangesAsync();
                return true;
            }
            catch (Exception ex)
            {
                throw ex;
            }

        }

        public async Task<List<User>> GetAll()
        {
            var userEntities = await _context.TblUser.Include(m => m.Role).Include(m => m.Section).Include(m => m.District).Include(m => m.Country).OrderBy(m => m.Email).ToListAsync();
            return userEntities.Select(m => new User
            {
                Id = m.Id,
                MiddleName = m.MiddleName,
                FirstName = m.FirstName,
                LastName = m.LastName,
                Address = m.Address,
                CreatedOn = m.CreatedOn,
                Gender = m.Gender,
                ImageFile = m.ImageFile,
                ImageSequence = m.ImageSequence,
                IsEmailVerify = m.IsEmailVerify,
                Lat = m.Lat,
                Long = m.Long,
                Name = m.FirstName + " " + m.LastName,
                Phone = m.Phone,
                Pincode = m.Pincode,
                SectionId = m.SectionId,
                SectionName = m.Section.Name,
                DistrictId = m.DistrictId,
                DistrictName = m.District?.Name,
                CountryId = m.CountryId,
                CountryName = m.Country?.Name,
                UserName = m.UserName,
                Email = m.Email,
                RoleName = m.Role.Name,
                RoleId = m.RoleId,
                IsSuperAdmin = m.IsSuperAdmin,
                IsActive = m.IsActive,
                City = m.City,
                WorkPhoneNo = m.WorkPhoneNo,
                TelePhoneNo = m.TelePhoneNo,
                Status = m.Status,
            }).ToList();
        }

        public async Task<List<User>> GetByRoleId(Guid roleId)
        {
            var userEntities = await _context.TblUser.Include(m => m.Role).Where(m => m.RoleId == roleId).ToListAsync();
            return userEntities.Select(m => new User
            {
                Id = m.Id,
                Name = m.FirstName + " " + m.LastName,
                Email = m.Email,
                RoleName = m.Role.Name,
                RoleId = m.RoleId,
                IsSuperAdmin = m.IsSuperAdmin,
                IsActive = m.IsActive
            }).ToList();
        }

        public async Task<List<User>> GetAllMissionariesUser()
        {
            var userEntities = await _context.TblUser.Include(m => m.Role).Where(m => m.Role.DataAccessCode =="M").ToListAsync();
            return userEntities.Select(m => new User
            {
                Id = m.Id,
                Name = m.FirstName + " " + m.LastName,
                IsSuperAdmin = m.IsSuperAdmin,
                IsActive = m.IsActive
            }).ToList();
        }

        public async Task<User> GetById(Guid id)
        {

            try
            {
                var userEntity = await _context.TblUser.Include(m => m.Role).Include(m => m.TblUserChurch).ThenInclude(m => m.Church).Include(m => m.TblUserAttribute)
                                .ThenInclude(m => m.Attribute).Include(m => m.Section).Include(m => m.District).Include(m => m.Country).FirstOrDefaultAsync(m => m.Id == id);
                var attributeEntities = await _context.TblAttribute.ToListAsync();


                return new User
                {
                    Id = userEntity.Id,
                    FirstName = userEntity.FirstName,
                    MiddleName = userEntity.MiddleName,
                    LastName = userEntity.LastName,
                    Address = userEntity.Address,
                    CreatedOn = userEntity.CreatedOn,
                    Gender = userEntity.Gender,
                    ImageFile = userEntity.ImageFile,
                    ImageSequence = userEntity.ImageSequence,
                    IsEmailVerify = userEntity.IsEmailVerify,
                    Lat = userEntity.Lat,
                    Long = userEntity.Long,
                    Name = userEntity.FirstName + " " + userEntity.LastName,
                    Phone = userEntity.Phone,
                    Pincode = userEntity.Pincode,
                    SectionId = userEntity.SectionId,
                    SectionName = userEntity.Section?.Name,
                    DistrictId = userEntity.DistrictId,
                    DistrictName = userEntity.District?.Name,
                    CountryId = userEntity.CountryId,
                    CountryName = userEntity.Country?.Name,
                    UserName = userEntity.UserName,
                    Email = userEntity.Email,
                    RoleName = userEntity.Role.Name,
                    RoleId = userEntity.RoleId,
                    IsSuperAdmin = userEntity.IsSuperAdmin,
                    IsActive = userEntity.IsActive,
                    City = userEntity.City,
                    WorkPhoneNo = userEntity.WorkPhoneNo,
                    TelePhoneNo = userEntity.TelePhoneNo,
                    Status = userEntity.Status,
                    Attributes = userEntity.TblUserAttribute.Select(m => new UserAttribute
                    {
                        Id = Guid.NewGuid(),
                        AttributeId = m.AttributeId,
                        AttributeTypeId = m.Attribute.AttributeTypeId,
                        AttributeValue = m.AttributeValue,
                        UserId = userEntity.Id,
                        Notes = m.Notes,
                        Butes = attributeEntities.Where(n => n.AttributeTypeId == m.Attribute.AttributeTypeId).Select(n => new AttributeModel
                        {
                            Id = n.Id,
                            AttributeName = n.AttributeName
                        }).ToList()
                    }).ToList(),
                    Churches = userEntity.TblUserChurch.Select(m => new UserChurch
                    {
                        ChurchId = m.ChurchId,
                        ChurchName = m.Church.ChurchName,
                        CreatedOn = DateTime.Now,
                        RelationType = m.RelationType,
                        UserId = userEntity.Id,
                    }).ToList()
                };
            }
            catch (Exception ex)
            {
                throw;
            }


        }

        public async Task<QueryResult<User>> Search(UserQuery query)
        {
            try
            {
                var skip = (query.Page - 1) * query.Limit;
                var userQuery = _context.TblUser.Include(m => m.Role).Include(m => m.Section).Include(m => m.District).Include(m => m.Country).AsNoTracking().AsQueryable();

                if (!string.IsNullOrEmpty(query.Name))
                {
                    userQuery = userQuery.Where(m => m.FirstName.Contains(query.Name) || m.LastName.Contains(query.Name) || m.Role.Name.Contains(query.Name) || m.Email.Contains(query.Name) 
                                || m.Phone.Contains(query.Name) || m.District.Name.Contains(query.Name) || m.Section.Name.Contains(query.Name));
                }
                var count = await userQuery.CountAsync();

                switch (query.Order.ToLower())
                {
                    case "role":
                        userQuery = userQuery.OrderBy(m => m.Role.Name);
                        break;
                    case "-role":
                        userQuery = userQuery.OrderByDescending(m => m.Role.Name);
                        break;
                    case "email":
                        userQuery = userQuery.OrderBy(m => m.Email);
                        break;
                    case "-email":
                        userQuery = userQuery.OrderByDescending(m => m.Email);
                        break;
                    case "phone":
                        userQuery = userQuery.OrderBy(m => m.Phone);
                        break;
                    case "-phone":
                        userQuery = userQuery.OrderByDescending(m => m.Phone);
                        break;
                    case "district":
                        userQuery = userQuery.OrderBy(m => m.District.Name);
                        break;
                    case "-district":
                        userQuery = userQuery.OrderByDescending(m => m.District.Name);
                        break;
                    case "section":
                        userQuery = userQuery.OrderBy(m => m.Section.Name);
                        break;
                    case "-section":
                        userQuery = userQuery.OrderByDescending(m => m.Section.Name);
                        break;
                    default:
                        userQuery = query.Order.StartsWith("-") ? userQuery.OrderByDescending(m => m.FirstName) : userQuery.OrderBy(m => m.FirstName);
                        break;
                }
                var userEntities = await userQuery.Skip(skip).Take(query.Limit).ToListAsync();
                var users = userEntities.Select(m => new User
                {
                    Id = m.Id,
                    MiddleName = m.MiddleName,
                    FirstName = m.FirstName,
                    LastName = m.LastName,
                    Address = m.Address,
                    CreatedOn = m.CreatedOn,
                    Gender = m.Gender,
                    ImageFile = m.ImageFile,
                    ImageSequence = m.ImageSequence,
                    IsEmailVerify = m.IsEmailVerify,
                    Lat = m.Lat,
                    Long = m.Long,
                    Name = m.FirstName + " " + m.LastName,
                    Phone = m.Phone,
                    Pincode = m.Pincode,
                    SectionId = m.SectionId,
                    SectionName = m.Section?.Name,
                    DistrictId = m.DistrictId,
                    DistrictName = m.District?.Name,
                    CountryId = m.CountryId,
                    CountryName = m.Country?.Name,
                    UserName = m.UserName,
                    Email = m.Email,
                    RoleName = m.Role.Name,
                    RoleId = m.RoleId,
                    IsSuperAdmin = m.IsSuperAdmin,
                    IsActive = m.IsActive,
                    ActiveStatus = m.IsActive ? "Active" : "In-Active",
                    UserStatus = m.IsSuperAdmin ? "Yes" : "No",
                    City = m.City,
                    WorkPhoneNo = m.WorkPhoneNo,
                    TelePhoneNo = m.TelePhoneNo,
                    Status = m.Status,
                }).ToList();

                return new QueryResult<User> { Result = users, Count = count };
            }
            catch (Exception ex)
            {
                return null;
            }
        }

        public async Task<int> Save(User user)
        {
            try
            {
                var existingEntity = await _context.TblUser.Where(m => m.Email.ToLower() == user.Email.ToLower()).FirstOrDefaultAsync();
                if (existingEntity != null)
                {
                    return -1;
                }

                var userEntity = new TblUser();
                var userId = Guid.NewGuid();
                if (user.Id == Guid.Empty)
                {
                    userEntity.Id = userId;
                    userEntity.FirstName = user.FirstName;
                    userEntity.LastName = user.LastName;
                    userEntity.ImageFile = user.ImageFile;
                    userEntity.ImageSequence = user.ImageSequence;
                    userEntity.Address = user.Address;
                    userEntity.CreatedOn = DateTime.Now;
                    userEntity.Gender = user.Gender;
                    userEntity.IsEmailVerify = false;
                    userEntity.Lat = user.Lat;
                    userEntity.Long = user.Long;
                    userEntity.Phone = user.Phone;
                    userEntity.Pincode = user.Pincode;
                    userEntity.SectionId = user.SectionId;
                    userEntity.DistrictId = user.DistrictId;
                    userEntity.CountryId = user.CountryId;
                    userEntity.UserName = user.UserName;
                    userEntity.Email = user.Email;
                    userEntity.IsSuperAdmin = user.IsSuperAdmin;
                    userEntity.IsActive = user.IsActive;
                    userEntity.RoleId = user.RoleId;

                    var attributes = user.Attributes.Select(m => new TblUserAttribute
                    {
                        Id = Guid.NewGuid(),
                        AttributeId = m.AttributeId,
                        AttributeValue = m.AttributeValue,
                        UserId = userId,
                        Notes = m.Notes,
                    }).ToList();

                    userEntity.TblUserAttribute = attributes;

                    var churches = user.Churches.Select(m => new TblUserChurch
                    {
                        ChurchId = m.ChurchId,
                        CreatedOn = DateTime.Now,
                        RelationType = m.RelationType,
                        UserId = userId,
                    }).ToList();

                    userEntity.TblUserChurch = churches;

                    var model = new TblUserPassword
                    {
                        Id = Guid.NewGuid(),
                        CreatedOn = DateTime.Now,
                        IsActive = true,
                        Password = user.Password,
                        UserId = userId,
                    };

                    userEntity.TblUserPassword.Add(model);

                    _context.TblUser.Add(userEntity);
                }
                else
                {
                    existingEntity = await _context.TblUser.Where(m => m.Email.ToLower() == user.Email.ToLower() && m.Id != user.Id).FirstOrDefaultAsync();
                    if (existingEntity != null)
                    {
                        return -1;
                    }

                    userEntity = await _context.TblUser.Include(m => m.TblUserPassword).Include(m => m.TblUserChurch).Include(m => m.TblUserAttribute).FirstOrDefaultAsync(m => m.Id == user.Id);

                    userEntity.FirstName = user.FirstName;
                    userEntity.LastName = user.LastName;
                    userEntity.ImageFile = user.ImageFile;
                    userEntity.ImageSequence = user.ImageSequence;
                    userEntity.Address = user.Address;
                    userEntity.Gender = user.Gender;
                    userEntity.Lat = user.Lat;
                    userEntity.Long = user.Long;
                    userEntity.Phone = user.Phone;
                    userEntity.Pincode = user.Pincode;
                    userEntity.SectionId = user.SectionId;
                    userEntity.DistrictId = user.DistrictId;
                    userEntity.CountryId = user.CountryId;
                    userEntity.UserName = user.UserName;
                    userEntity.Email = user.Email;
                    userEntity.IsSuperAdmin = user.IsSuperAdmin;
                    userEntity.IsActive = user.IsActive;
                    userEntity.RoleId = user.RoleId;

                    _context.TblUserAttribute.RemoveRange(userEntity.TblUserAttribute);
                    _context.TblUserChurch.RemoveRange(userEntity.TblUserChurch);

                    await _context.SaveChangesAsync();

                    var attributes = user.Attributes.Select(m => new TblUserAttribute
                    {
                        Id = Guid.NewGuid(),
                        AttributeId = m.AttributeId,
                        AttributeValue = m.AttributeValue,
                        UserId = userId,
                        Notes = m.Notes,
                    }).ToList();

                    userEntity.TblUserAttribute = attributes;

                    var churches = user.Churches.Select(m => new TblUserChurch
                    {
                        ChurchId = m.ChurchId,
                        CreatedOn = DateTime.Now,
                        RelationType = m.RelationType,
                        UserId = userId,
                    }).ToList();

                    userEntity.TblUserChurch = churches;

                    //var model = new TblUserPassword
                    //{
                    //    Id = Guid.NewGuid(),
                    //    CreatedOn = DateTime.Now,
                    //    IsActive = true,
                    //    Password = user.Password,
                    //    UserId = userId,
                    //};

                    //userEntity.TblUserPassword.Add(model);
                }

                await _context.SaveChangesAsync();
                return 1;
            }
            catch (Exception ex)
            {
                return 0;
            }
        }

        public async Task<User> Validate(string email, string password)
        {
            var userEntity = await _context
                .TblUser.Include(m => m.Role).Include(m => m.TblUserPassword)
                .FirstOrDefaultAsync(m => m.Email.Equals(email)
                && m.TblUserPassword.OrderByDescending(n => n.CreatedOn).FirstOrDefault().Password.Equals(password)
                && m.IsActive);
            if (userEntity == null)
            {
                return null;
            }
            var menuGroups = await _menuGroupService.GetAll();

            var userRole = await _menuGroupService.GetRoleMenuAccess(userEntity.Id);

            if (userEntity == null)
            {
                return null;
            }

            return new User
            {
                Name = userEntity.FirstName + " " + userEntity.LastName,
                Id = userEntity.Id,
                Email = userEntity.Email,
                IsSuperAdmin = userEntity.IsSuperAdmin,
                RoleId = userEntity.RoleId,
                RoleName = userEntity.Role.Name,
                DataAccessCode = userEntity.Role.DataAccessCode,
                Groups = menuGroups.Select(m => new GroupPermission
                {
                    GroupId = m.Id,
                    GroupName = m.Name,
                    Category = m.Category,
                    GroupPosition = m.DisplayPosition,
                    Icon = m.Icon,
                    Sequence = m.Sequence,
                    Target = m.Target,
                    DefaultCategory = m.Category
                }).ToList(),
                Permissions = userRole.AccessMenus.Select(m => new MenuPermission
                {
                    MenuId = m.MenuId,
                    MenuName = m.MenuName,
                    NameBeng = m.NameBeng,
                    MenuIcon = m.MenuIcon,
                    MenuTarget = m.MenuTarget,
                    MenuPosition = m.MenuPosition,
                    MenuGroupId = m.MenuGroupId,
                    HasReadAccess = m.HasReadAccess,
                    HasWriteAccess = m.HasWriteAccess,
                    HasFullAccess = m.HasFullAccess
                }).ToList()
            };
        }

        public async Task<List<RoleMenu>> GetMenuByUser(Guid userId)
        {
            var user = await _context.TblUser.FirstOrDefaultAsync(m => m.Id == userId);
            var apps = (user.IsSuperAdmin) ? await _menuService.GetAll() : await _menuService.GetByRole(user.RoleId);
            var appGroups = apps.OrderBy(m => m.MenuGroupName).Select(m => m.MenuGroupName).Distinct();
            var allApps = new List<RoleMenu>();
            foreach (var appGroup in appGroups)
            {
                var groupApps = apps.Where(m => m.MenuGroupName.Equals(appGroup)).OrderBy(m => m.Position);
                allApps.Add(new RoleMenu
                {
                    AppName = appGroup,
                    Menus = groupApps.Select(m => new RoleMenu
                    {
                        AppName = m.Name,
                        Path = m.StartingPath
                    }).ToList()
                });
            }

            return allApps;
        }
    }
}
